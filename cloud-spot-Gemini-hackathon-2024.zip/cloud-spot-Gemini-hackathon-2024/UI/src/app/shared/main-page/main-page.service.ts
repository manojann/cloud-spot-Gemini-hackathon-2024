import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, of } from 'rxjs';
import { ConfigService } from '../config-service/config.service';

@Injectable({
  providedIn: 'root'
})
export class MainPageService {

  constructor(public http: HttpClient, public configService: ConfigService) { }



  invoke_tool(payload: any) {
    console.log("this.configService.getConfigDataValue", this.configService.getConfigDataValue)
    console.log("this.configService.getConfigDataValue.baseUrl", this.configService.getConfigDataValue.baseUrl)
    const url = this.configService.getConfigDataValue.baseUrl + "invoke_tool"
    return this.http.post(url, payload)
  }

  invoke_llm(payload: any) {
    const url = this.configService.getConfigDataValue.baseUrl + "invoke_llm"
    return this.http.post(url, payload)
  }
}
