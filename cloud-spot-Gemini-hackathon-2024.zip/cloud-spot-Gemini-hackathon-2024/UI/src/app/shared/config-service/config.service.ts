import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  public configData: BehaviorSubject<any>= new BehaviorSubject<any>(null);
  public configDataResponse: Observable<any>=this.configData.asObservable();

  constructor(private http: HttpClient) { }

  get getConfigDataValue(){
    return this.configData.value
  }

  
  getConfigData(){
    this.http.get("../../../assets/config.json").subscribe((res)=>{
      console.log("res",res)
      this.configData.next(res) 
    })
  }
}

export interface SpeechRecognition extends EventTarget {
  grammars: any;
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onaudiostart: ((this: SpeechRecognitionEvent) => any) | null;
  onaudioend: ((this: SpeechRecognitionEvent) => any) | null;
  onend: ((this: SpeechRecognitionEvent) => any) | null;
  onerror: ((this: SpeechRecognitionError) => any) | null;
  onnomatch: ((this: SpeechRecognitionEvent) => any) | null;
  onresult: ((this: SpeechRecognitionEvent) => any) | null;
  onsoundstart: ((this: SpeechRecognitionEvent) => any) | null;
  onsoundend: ((this: SpeechRecognitionEvent) => any) | null;
  onspeechstart: ((this: SpeechRecognitionEvent) => any) | null;
  onspeechend: ((this: SpeechRecognitionEvent) => any) | null;
  onstart: ((this: SpeechRecognitionEvent) => any) | null;
  abort(): void;
  start(): void;
  stop(): void;
  addEventListener<K extends keyof SpeechRecognitionEventMap>(
    type: K,
    listener: (this: SpeechRecognition, ev: SpeechRecognitionEventMap[K]) => any,
    options?: boolean | AddEventListenerOptions
  ): void;
}

export interface SpeechRecognitionEventMap {
  audiostart: Event;
  audioend: Event;
  end: Event;
  error: Event;
  nomatch: Event;
  result: SpeechRecognitionEvent;
  soundstart: Event;
  soundend: Event;
  speechstart: Event;
  speechend: Event;
  start: Event;
}

export interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}

export interface SpeechRecognitionResultList {
  [index: number]: SpeechRecognitionResult;
  length: number;
}

export interface SpeechRecognitionResult {
  [index: number]: SpeechRecognitionAlternative;
  length: number;
}

export interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

export interface SpeechRecognitionError extends Event {
  error: string;
}
