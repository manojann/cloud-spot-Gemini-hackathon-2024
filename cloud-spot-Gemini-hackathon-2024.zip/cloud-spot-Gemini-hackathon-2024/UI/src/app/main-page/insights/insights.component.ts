import { Component, Input } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-insights',
  templateUrl: './insights.component.html',
  styleUrls: ['./insights.component.css']
})
export class InsightsComponent {
  @Input() normal_results_b64: any=[];
  @Input() rolling_results_b64: any=[];
  @Input() agentScratchpad: any='';

  constructor(private sanitizer: DomSanitizer){}

  getImageUrl(imageName: string) {
    return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${imageName}`)
  }

    restructretedAgentScratchpad(botReply: string) {
    // botReply = botReply.replace('\n', '');
    const urlRegex = /((http|https):\/\/[^\s]+)/g;
    let replacedText = botReply.replace(urlRegex, '<a href="$1" target="_blank">$1</a>');
    replacedText = replacedText.replace(/\n/g, '<br>');
    return replacedText;
  }
}
