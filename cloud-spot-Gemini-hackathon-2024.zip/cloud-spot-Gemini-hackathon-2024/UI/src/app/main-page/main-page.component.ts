import { ToastrService } from 'ngx-toastr';
import { Component } from '@angular/core';
import { MainPageService } from '../shared/main-page/main-page.service';
import { ConfigService } from '../shared/config-service/config.service';


@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent {
  loggedinUser: any;
  userImageUrl: string = '';
  agentScratchpad: any = '';
  chosenMachineType: any = "g4dn.xlarge";
  numHours: any = 1;
  machineTypes = ["g4dn.xlarge", "g4dn.2xlarge", "g4dn.4xlarge"]
  isInvoketoolenabled: boolean = false;
  solution: any = '';
  normal_results_b64: any = [];
  rolling_results_b64: any = [];
  recommendedInstruction: any = [];
  currentInstruction: any = {};
  expected_savings: any = [];
  currentTime = new Date();

  constructor(public mainPageService: MainPageService, public toastr: ToastrService, public configService: ConfigService) { }


  ngOnInit() {

    this.loggedinUser = "admin";

  }

  invoke_tool() {
    this.isInvoketoolenabled = true
    let payload = {
      "chosenMachineType": this.chosenMachineType,
      "numHours": this.numHours
    }
    this.mainPageService.invoke_tool(payload).subscribe((res: any) => {
      this.agentScratchpad = res.solutionString;
      this.solution = res.solution;
      this.normal_results_b64 = res.normal_results_b64;
      this.rolling_results_b64 = res.rolling_results_b64;
      this.expected_savings = res.expected_savings;
      this.isInvoketoolenabled = false;
      this.recommendedInstruction.push(this.createObjects(this.solution))
      this.currentInstruction = this.createCurrentInstruction()
      console.log(this.currentInstruction)
    }, (error: any) => {
      this.toastr.error("Error in invoking tool")
      this.agentScratchpad = ""
      this.solution = ""
      this.normal_results_b64 = []
      this.rolling_results_b64 = []
      this.expected_savings = []
      this.isInvoketoolenabled = false;
      this.currentInstruction = {}
    });
  }

  onModelChange(event: any) {
    this.chosenMachineType = event.target.value;
    console.log(this.chosenMachineType)
  }


  createCurrentInstruction() {
    let zone = "us-east-1a"
    const timestamp = new Date(this.currentTime.getTime()).toISOString();  
          const projectId = "project-id"; // replace with actual project ID  
          const instanceId = Math.random().toString(36).substring(2, 18);  
    
          const resource = {  
            "name": `projects/${projectId}/zones/${zone}/instances/${instanceId}`,  
            "type": "compute.googleapis.com/Instance",  
            "labels": {  
              "zone": zone,  
              "instance_id": instanceId,  
              "project_id": projectId  
            }  
          };  
    
          const data = {  
            "zone": zone,  
            "instance_id": instanceId,  
            "project_id": projectId  
          };  
    
          const obj = {  
            "eventType": "compute.instance.preempted",  
            "resource": resource,  
            "timestamp": timestamp,  
            "data": data  
          };  
    
    return obj
  }


  createObjects(data: { [key: string]: string }[]) {  
    const objects: any = [];  
    
    data.forEach((row, index) => {  
      Object.entries(row).forEach(([zone, value]) => {  
        if (value.startsWith('Yes')) {  
          const timestamp = new Date(this.currentTime.getTime() + index * 60 * 60 * 1000).toISOString();  
          const projectId = "project-id"; // replace with actual project ID  
          const instanceId = Math.random().toString(36).substring(2, 18);  
    
          const resource = {  
            "name": `projects/${projectId}/zones/${zone}/instances/${instanceId}`,  
            "type": "compute.googleapis.com/Instance",  
            "labels": {  
              "zone": zone,  
              "instance_id": instanceId,  
              "project_id": projectId  
            }  
          };  
    
          const data = {  
            "zone": zone,  
            "instance_id": instanceId,  
            "project_id": projectId  
          };  
    
          const obj = {  
            "eventType": "compute.instance.preempted",  
            "resource": resource,  
            "timestamp": timestamp,  
            "data": data  
          };  
    
          objects.push(obj);  
        }  
      });  
    });  
    
    return objects;  
  }  
  

  submitSQSInsrutructions(){
    this.toastr.success("Recommended SQS instructions submitted successfully")
  }

}