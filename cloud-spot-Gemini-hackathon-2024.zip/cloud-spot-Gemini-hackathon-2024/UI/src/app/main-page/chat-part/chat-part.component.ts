import { ChangeDetectorRef, Component, ElementRef, Input, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { SpeechRecognitionEvent } from 'src/app/shared/config-service/config.service';
import { FeedbackPopupComponent } from './feedback-popup/feedback-popup.component';
import { MainPageService } from 'src/app/shared/main-page/main-page.service';

@Component({
  selector: 'app-chat-part',
  templateUrl: './chat-part.component.html',
  styleUrls: ['./chat-part.component.css']
})
export class ChatPartComponent {
  loggedinUser: any;
  loggedinUserName: any;
  userImageUrl: string = '';
  messages: { text: string, isMe: boolean, timestamp: any, sender: string, feedbackType: string, feedback: string, timeTaken: any, isPlay?: boolean,base64Image:string}[] = [];
  isResponseGenrated = false;
  isSendClicked = false;
  time = new Date();
  isErrorRecorded: boolean = false;
  totalTokens: number = 0;
  currentMessage: string = '';
  userMessage: string[] = [];
  botMessage: string[] = [];
  lastUserQuery: string = '';
  lastBotResponse: string = '';
  errorText: any = '';
  isTooltipVisible = false;
  @ViewChild('tooltipButton')
  tooltipButton!: ElementRef;
  @ViewChild('tooltipPanel')
  tooltipPanel!: ElementRef;
  utterance!: SpeechSynthesisUtterance;
  voices!: SpeechSynthesisVoice[];
  recognition!: any;
  recognitionStarted: boolean = false;
  dialogRef: any;
  @ViewChild('cardBody')
  cardBody!: ElementRef;
  messagesHistory: any=[];
  @Input() agentScratchpad: any='';
  @Input() solution: any='';
  displayColumns: string[] = ["timestamp","us-east-1a","us-east-1b","us-east-1c","us-east-1d"]
  predefinedQuestions: any[] = [
   "Provide me the list of machines that should be provisioned based on forecasting models with a forecasted spot price.",
   "Help me provision machines based on forecasted spot prices.",
   "Explain the modeling process.",
   "Show a summary of time series models and compare performance.",
   "Show features that are used for time series models.",
   "How is provisioning being done?"
  ]
  @Input() expected_savings: any =[];
  @Input() currentTime:Date = new Date();

  constructor(public mainPageService: MainPageService, public dialog: MatDialog, private sanitizer: DomSanitizer, private changeDetectorRef: ChangeDetectorRef) { }


  ngOnInit() {
    
      this.loggedinUserName = "admin"
      this.loggedinUser = "admin";
      this.userImageUrl = 'assets/' + 'admin.png'
    // Check if browser supports SpeechRecognition
    if ('webkitSpeechRecognition' in window) {
      // Create a new instance of SpeechRecognition
      this.recognition = new (window as any).webkitSpeechRecognition();

      // // Configure recognition options
      this.recognition.continuous = true;
      // this.recognition.interimResults = true;

      this.recognition.onresult = (event: SpeechRecognitionEvent) => {
        const result: any = event.results[event.results.length - 1];
        const transcript = result[0].transcript;
        this.currentMessage += transcript + ' ';
        this.changeDetectorRef.detectChanges();
      };
    } else {
      console.log('Speech recognition not supported in this browser.');
    }

  }


  ngAfterViewInit() {
    if (this.tooltipButton) {
      this.tooltipButton.nativeElement.addEventListener('mouseenter', () => {
        this.isTooltipVisible = true;
      });

      this.tooltipButton.nativeElement.addEventListener('mouseleave', () => {
        this.isTooltipVisible = false;
      });
    }

    if (this.tooltipPanel) {
      this.tooltipPanel.nativeElement.addEventListener('mouseenter', () => {
        this.isTooltipVisible = true;
      });

      this.tooltipPanel.nativeElement.addEventListener('mouseleave', () => {
        this.isTooltipVisible = false;
      });
    }

  }
  sendMessage() {
    if (this.currentMessage.trim() !== '') {
      this.isErrorRecorded = false;
      this.stopListening()
      this.isResponseGenrated = false;
      this.isSendClicked = true;
      this.messages.push({ text: this.currentMessage, isMe: true, timestamp: new Date(), sender: 'You', feedbackType: '', feedback: '', timeTaken: '', isPlay: false,base64Image:''});
      this.messagesHistory.push(this.currentMessage)
      this.scrollBottom();
      this.userMessage.push(this.currentMessage);
      let payload = {
        "message": this.currentMessage,
        "history": this.messagesHistory,
        "agentScratchpad": this.agentScratchpad
      }
      this.mainPageService.invoke_llm(payload).subscribe(async (response: any) => {
        this.currentMessage = '';
        this.isResponseGenrated = true;
        this.isSendClicked = false;
        this.botMessage.push(response.output[0]);
        this.messagesHistory.push(response.output[0])
        let botReply = await this.restructretedMessage(response.output[0])
        let base64Image = ''
        if (response.output.length > 1) {
        base64Image = response.output[1]
        }
        this.messages.push({ text: botReply, isMe: false, timestamp: new Date(), sender: 'Bot', feedbackType: '', feedback: '', timeTaken: response.timeTaken, isPlay: false ,base64Image:base64Image });
        this.scrollBottom();

      }, (error: any) => {
        this.isResponseGenrated = true;
        this.isSendClicked = false;
        this.isErrorRecorded = true;

        if (error.error.results) {
          this.errorText = error.error.results
        }
        else {
          this.errorText = 'Something Went Wrong! Please Refresh the Page.'
        }
      });
    }
  }

  restructretedMessage(botReply: string) {
    // botReply = botReply.replace('\n', '');
    const urlRegex = /((http|https):\/\/[^\s]+)/g;
    let replacedText = botReply.replace(urlRegex, '<a href="$1" target="_blank">$1</a>');
    replacedText = replacedText.replace(/\n/g, '<br>');
    return replacedText;
  }


  // getToolTipMesaage(message: any) {
  //   return 'Response time: ' + message.timeTaken + ' Sec '
  // }

  playText(message: any) {
    message.isPlay = true;
    this.utterance = new SpeechSynthesisUtterance(message.text);
    // Set the voice for speech synthesis
    this.voices = speechSynthesis.getVoices();
    this.utterance.voice = this.voices[0];

    // Cancel any ongoing speech synthesis
    speechSynthesis.cancel();
    // Play the response
    speechSynthesis.speak(this.utterance);
  }

  pauseText(message: any) {
    message.isPlay = false;
    speechSynthesis.cancel();
  }


  startListening() {
    this.currentMessage = '';
    this.recognitionStarted = true;
    this.recognition.start();
  }

  stopListening() {
    this.recognitionStarted = false;
    this.recognition.stop();
  }

  onFeedBackClicked(feedbackType: string, index: number) {
    this.messages[index].feedbackType = feedbackType;
    // console.log(this.messages);
    // if (this.messages[index].feedback == "") {
    //   this.feedbackPopup(index)
    // }
  }


  // feedbackPopup(index: number) {

  //   // if (!this.dialogRef) {
  //   //   this.dialogRef = this.dialog.open(FeedbackPopupComponent, {
  //   //     width: '700px',
  //   //     height: '250px'
  //   //   });

  //   //   this.dialogRef.afterClosed().subscribe((result: any) => {
  //   //     if (result) {
  //         this.messages[index].feedback = result
  //   //       let payload = {
  //   //         chatHistory: this.messages,
  //   //       }
  //   //       this.dialogRef = null;
  //   //     } else {
  //   //       this.dialogRef = null;
  //   //     }

  //   //   });
  //   // }
  // }

  scrollBottom() {
    setTimeout(() => {
      this.cardBody.nativeElement.scrollTop = this.cardBody.nativeElement.scrollHeight - this.cardBody.nativeElement.offsetHeight;
    }, 50);
  }


  sendPredefinedQue(que: string) {
    this.currentMessage = que;
    this.sendMessage()
  }



  getImageUrl(imageName: string) {
    return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${imageName}`)
  }


  getTimeStamp(noOfHour: any) {
    return new Date(this.currentTime.getTime() + (noOfHour * 60 * 60 * 1000));  
  }

  getConvertedValue(value: any) {
    return Number(value).toFixed(4)
  }

  getMax(value: any) {
    return Math.max(...value).toFixed(4)
  }
}
