import base64
from io import BytesIO
import matplotlib.pyplot as plt
from flask_cors import CORS
from flask import Flask, request, jsonify, make_response
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
import boto3
import datetime
import pandas as pd
import csv
from sktime.forecasting.arima import ARIMA
from sktime.forecasting.sarimax import SARIMAX
from sktime.forecasting.fbprophet import Prophet
from sktime.split import temporal_train_test_split
import numpy as np
import dimod
import neal
from botocore.exceptions import NoCredentialsError
import boto3
import os
import json
import requests

from langchain_google_genai import (
    ChatGoogleGenerativeAI,
    HarmBlockThreshold,
    HarmCategory,
)

import matplotlib

matplotlib.use("Agg")


aws_access_key_id = "your key"
aws_secret_access_key = "your key"

test_set_split = 0.2
rolling_interval = 1

num_time_steps = 10

GEMINI_API_KEY = "your key"

os.environ["GOOGLE_API_KEY"] = GEMINI_API_KEY

plt.ioff()
plt.rcParams["interactive"] = False


def plot_results(
    true_values, arima_results, sarimax_results, prophet_results, test_values
):
    plt.plot(true_values, label="True values", color="blue")
    plt.plot(arima_results, label="ARIMA", color="red")
    plt.plot(sarimax_results, label="SARIMAX", color="purple")
    plt.plot(prophet_results, label="Prophet", color="yellow")
    plt.plot(test_values, label="Test values", color="green")
    plt.xlabel("Timestamp")
    plt.ylabel("Spot Price")
    plt.legend(loc="best")

    buffer = BytesIO()
    plt.savefig(buffer, format="png")
    plt.close()
    image_bytes = buffer.getvalue()

    # Encode the bytes in base64
    base64_string = base64.b64encode(image_bytes).decode("utf-8")
    return base64_string


def get_ondemand_price(region_name, instance_type):
    url = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEC2/current/{}/index.json".format(
        region_name
    )
    response = requests.get(url)
    json_response = json.loads(response.text)

    # Parse the JSON and get the price
    for product in json_response["products"].values():
        if product["productFamily"] == "Compute Instance":
            if product["attributes"]["instanceType"] == instance_type:
                sku = product["sku"]
                price_dimensions = list(
                    json_response["terms"]["OnDemand"][sku].values()
                )[0]["priceDimensions"]
                price = list(price_dimensions.values())[0]["pricePerUnit"]["USD"]
                return price

    return None


def get_spot_price_data(machine_type, availability_zone):
    MAX_RESULTS = 100

    try:
        # Create a client
        ec2 = boto3.client(
            "ec2",
            region_name="us-east-1",
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )

        # Specify your start date
        start_time = datetime.datetime.strptime("2023-01-01", "%Y-%m-%d")

        # Calculate yesterday's date
        end_time = datetime.datetime.now() - datetime.timedelta(days=1)

        # Initialize an empty response dictionary and a next_token variable
        response = {}
        next_token = None

        # Initialize a counter
        counter = 0

        # Open the CSV file
        with open(
            f"spot_price_history_{availability_zone}.csv", "w", newline=""
        ) as file:
            writer = csv.writer(file)
            writer.writerow(["Timestamp", "SpotPrice", "InstanceType"])

            # While there are more results to fetch and the counter is less than 500
            while counter < MAX_RESULTS:
                # Make the request
                if counter == 0:
                    response = ec2.describe_spot_price_history(
                        StartTime=start_time,
                        EndTime=end_time,
                        InstanceTypes=[machine_type],
                        AvailabilityZone=availability_zone,
                        ProductDescriptions=[
                            "Linux/UNIX (Amazon VPC)",
                        ],
                        MaxResults=MAX_RESULTS,
                    )
                else:
                    response = ec2.describe_spot_price_history(
                        StartTime=start_time,
                        EndTime=end_time,
                        InstanceTypes=[machine_type],
                        AvailabilityZone=availability_zone,
                        ProductDescriptions=[
                            "Linux/UNIX (Amazon VPC)",
                        ],
                        MaxResults=MAX_RESULTS,
                        NextToken=next_token,
                    )

                # Write the results to the CSV file
                for item in response["SpotPriceHistory"]:
                    writer.writerow(
                        [item["Timestamp"], item["SpotPrice"], item["InstanceType"]]
                    )
                    counter += 1
                    if counter >= MAX_RESULTS:
                        break

                # Get the next token
                if "NextToken" in response:
                    next_token = response["NextToken"]
                else:
                    break

        print(
            f"The spot price history has been saved to spot_price_history_{availability_zone}.csv."
        )

    except NoCredentialsError:
        print("No credentials have been found.")


def prepare_all_data(machine_type, last_samples=750):
    for zone in av_zones:
        get_spot_price_data(machine_type, zone)

    dataframes = []
    csv_files = [
        filename
        for filename in sorted(os.listdir(os.getcwd()))
        if filename.endswith(".csv") and filename.startswith("spot_price_history")
    ]
    for filename in csv_files:
        if filename.endswith(".csv") and filename.startswith("spot_price_history"):
            zone = filename.split("spot_price_history_")[1].split(".csv")[0]
            filepath = os.path.join(os.getcwd(), filename)
            df = pd.read_csv(filepath)

            df["Timestamp"] = pd.to_datetime(df["Timestamp"])
            df["SpotPrice"] = pd.to_numeric(df["SpotPrice"])
            df[f"SpotPrice_{zone}"] = df["SpotPrice"]
            df.drop(columns=["SpotPrice", "InstanceType"], inplace=True)

            df.reset_index(drop=True, inplace=True)
            df.set_index("Timestamp", inplace=True)

            new_row = pd.DataFrame(
                [
                    {
                        "Timestamp": pd.Timestamp.now(tz="UTC").floor("1T"),
                        f"SpotPrice_{zone}": df[f"SpotPrice_{zone}"].iloc[-1],
                    }
                ]
            ).set_index("Timestamp")

            df = pd.concat([df, new_row], axis=0)
            df_resampled = df[f"SpotPrice_{zone}"].resample("5min").mean()
            df_resampled.ffill(inplace=True)
            df = df_resampled
            dataframes.append(df)

    df_combined = pd.concat([df for df in dataframes], axis=1).sort_values(
        by="Timestamp"
    )

    df_combined.reset_index(inplace=True)

    df_combined = df_combined[-last_samples:]

    return df_combined


GRAPH_SYSTEM_PROMPT = """
    You are a smart system that is only able to answer in the form of a JSON. You do not return any other word
    or phrase, only write JSONs.
    You are tasked with understanding if a user has asked a question around why a specific availability zone was
    chosen for a given timestep instead of others. You do not need to answer the question, you simply need to say
    if a given message is similar to, or has asked some form of this question or not.
    If the question is indeed similar, you will return the timestep for which the user has requested information.
    Availability zone here means the use of Amazon Web Services (AWS) availability zones for the selection of
    a certain zone to create a new AWS EC2 instance in.
    Do not create or make up any information that is not available to you. Always provide a helpful response and
    never say no to a question. Adhere to this message, only reply to a question with a Yes or No, no other word.

    The JSON schema format will always be {{"decision":<yes or no>, "timestep":<0 or n as per detection>}}.

    Some examples include:
    Question: Why was zone us-east-1a chosen for timestep 10?
    Answer: {{"decision":"Yes", "timestep":10}}

    Question: Why was zone us-east-1b chosen for timestep 5?
    Answer: {{"decision":"Yes", "timestep":5}}

    Question: Why was zone us-east-1c chosen for timestep 2?
    Answer: {{"decision":"Yes", "timestep":2}}

    Question: What is your name?
    Answer: {{decision:"No", "timestep":0}}

    You got this, you can do this!

    {message}
"""

graph_llm = ChatGoogleGenerativeAI(
    model="gemini-pro",
    convert_system_message_to_human=True,
    safety_settings={
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
    },
)

graph_check_prompt = ChatPromptTemplate.from_messages(
    [
        ("human", GRAPH_SYSTEM_PROMPT),
    ]
)

graph_output_parser = StrOutputParser()

graph_chain = (
    {
        "message": lambda x: x["message"],
    }
    | graph_check_prompt
    | graph_llm
    | graph_output_parser
)


def check_for_graph_question(message):
    # read message for to understand the intent of whether the user has
    # asked for details on why a certain zone is chosen or not by
    # sending the message to gemini and then let it return a yes or no
    # and depending on it, return a graph or not
    gemini_decision = graph_chain.invoke(
        {
            "message": message,
        }
    ).strip()
    gemini_info = json.loads(gemini_decision)
    if gemini_info["decision"] == "Yes":
        prices_df = pd.read_csv("forecast_results.csv")
        select_prices = prices_df.iloc[gemini_info["timestep"], :]
        bar_graph = plt.bar(av_zones, select_prices)
        select_prices = [round(price, 4) for price in select_prices]
        plt.bar_label(bar_graph, select_prices)
        plt.xlabel("Zone")
        plt.ylabel("Spot Price")

        buffer = BytesIO()
        plt.savefig(buffer, format="png")
        plt.close()
        image_bytes = buffer.getvalue()

        # Encode the bytes in base64
        base64_string = base64.b64encode(image_bytes).decode("utf-8")
        return base64_string
    else:
        return None


def solution_mapper(json_solution, price_vals):
    res_mapper = {1: "Yes\n", 0: "No\n"}
    for idx1, elem in enumerate(json_solution):
        for idx2, (zone, value) in enumerate(elem.items()):
            elem[zone] = res_mapper[value] + f"{price_vals.iloc[idx1, idx2]}"

    return json_solution


def forecast(
    machine_type: str = "g4dn.2xlarge",
    availability_zone: str = "us-east-1a",
    num_hours: int = 10,
    df: pd.DataFrame = None,
):

    df = df[["Timestamp", f"SpotPrice_{availability_zone}"]]
    df = df.rename(columns={f"SpotPrice_{availability_zone}": "SpotPrice"})

    train_series, test_series = temporal_train_test_split(
        df["SpotPrice"], test_size=test_set_split
    )

    true_values = train_series.dropna()
    rolling = train_series.rolling(window=rolling_interval * 60).mean().dropna()

    arima_forecaster = ARIMA(
        order=(1, 0, 0), seasonal_order=(0, 0, 0, 0), suppress_warnings=True
    )

    sarimax_forecaster = SARIMAX(
        order=(1, 0, 0), trend="t", seasonal_order=(0, 0, 0, 0)
    )

    prophet_forecaster = Prophet(
        seasonality_mode="multiplicative",
        add_country_holidays={"country_name": "UnitedStates"},
    )

    arima_forecaster.fit(true_values)
    sarimax_forecaster.fit(true_values)
    prophet_forecaster.fit(true_values)

    test_fh = np.array([i for i in range(1, test_series.shape[0] + 1, 1)])

    arima_results = arima_forecaster.predict(fh=test_fh)
    sarimax_results = sarimax_forecaster.predict(fh=test_fh)
    prophet_results = prophet_forecaster.predict(fh=test_fh)

    arima_forecaster.fit(rolling)
    sarimax_forecaster.fit(rolling)
    prophet_forecaster.fit(rolling)

    arima_results_rolling = arima_forecaster.predict(fh=test_fh)
    sarimax_results_rolling = sarimax_forecaster.predict(fh=test_fh)
    prophet_results_rolling = prophet_forecaster.predict(fh=test_fh)

    normal_results = plot_results(
        true_values, arima_results, sarimax_results, prophet_results, test_series
    )
    rolling_results = plot_results(
        true_values,
        arima_results_rolling,
        sarimax_results_rolling,
        prophet_results_rolling,
        test_series,
    )

    mse_loss_arima = ((test_series.to_numpy() - arima_results.to_numpy()) ** 2).mean()
    mse_loss_sarimax = (
        (test_series.to_numpy() - sarimax_results.to_numpy()) ** 2
    ).mean()
    mse_loss_prophet = (
        (test_series.to_numpy() - prophet_results.to_numpy()) ** 2
    ).mean()

    mse_loss_arima_rolling = (
        (test_series.to_numpy() - arima_results_rolling.to_numpy()) ** 2
    ).mean()
    mse_loss_sarimax_rolling = (
        (test_series.to_numpy() - sarimax_results_rolling.to_numpy()) ** 2
    ).mean()
    mse_loss_prophet_rolling = (
        (test_series.to_numpy() - prophet_results_rolling.to_numpy()) ** 2
    ).mean()

    # first choose between lowest mse of arima, sarimax or prophet
    # then choose between normal or rolling

    if mse_loss_arima < mse_loss_sarimax and mse_loss_arima < mse_loss_prophet:
        best_forecaster = "arima"
    elif mse_loss_sarimax < mse_loss_arima and mse_loss_sarimax < mse_loss_prophet:
        best_forecaster = "sarimax"
    else:
        best_forecaster = "prophet"

    if best_forecaster == "arima":
        if mse_loss_arima_rolling < mse_loss_arima:
            best_forecaster += "_rolling"
    elif best_forecaster == "sarimax":
        if mse_loss_sarimax_rolling < mse_loss_sarimax:
            best_forecaster += "_rolling"
    else:
        if mse_loss_prophet_rolling < mse_loss_prophet:
            best_forecaster += "_rolling"

    predict_fh = [i for i in range(test_fh.shape[0], test_fh.shape[0] + num_hours, 1)]

    if best_forecaster == "arima":
        if "rolling" in best_forecaster:
            arima_forecaster.fit(rolling)
        else:
            arima_forecaster.fit(true_values)
        results = arima_forecaster.predict(fh=predict_fh)

    elif best_forecaster == "sarimax":
        if "rolling" in best_forecaster:
            sarimax_forecaster.fit(rolling)
        else:
            sarimax_forecaster.fit(true_values)
        results = sarimax_forecaster.predict(fh=predict_fh)

    else:
        if "rolling" in best_forecaster:
            prophet_forecaster.fit(rolling)
        else:
            prophet_forecaster.fit(true_values)
        results = prophet_forecaster.predict(fh=predict_fh)

    true_cost = test_series.iloc[-1] * num_hours
    predicted_cost = results.sum()

    expected_savings = true_cost - predicted_cost

    return {
        "results": pd.Series(results),
        "normal_results": normal_results,
        "rolling_results": rolling_results,
        "decision_comments": f"""
            Machine Type chosen: {machine_type}
            Duration chosen for: {num_hours} hours
            Best forecaster for zone {availability_zone}: {best_forecaster} with lowest 
            MSE: {min(mse_loss_arima, mse_loss_sarimax, mse_loss_prophet, mse_loss_arima_rolling, mse_loss_sarimax_rolling, mse_loss_prophet_rolling)},
            and other MSEs for {availability_zone} being:
            - ARIMA: {mse_loss_arima}
            - SARIMAX: {mse_loss_sarimax}
            - Prophet: {mse_loss_prophet}
            - ARIMA Rolling: {mse_loss_arima_rolling}
            - SARIMAX Rolling: {mse_loss_sarimax_rolling}
            - Prophet Rolling: {mse_loss_prophet_rolling}
        """,
        "expected_savings": expected_savings,
    }


def machine_selection_algorithm(df, num_reads=500):
    # Convert prices to a matrix
    prices = df.values

    # Number of machines and time steps
    n_machines = prices.shape[1]
    n_steps = prices.shape[0]

    # Define the QUBO. The keys are (machine, time step) pairs
    Q = {}

    # Define the objective function
    for i in range(n_machines):
        for j in range(n_steps):
            Q[(i, j), (i, j)] = prices[j, i]

    # Define the constraint: exactly one machine has to be selected at each time step
    penalty = prices.max() * n_steps
    for j in range(n_steps):
        for i in range(n_machines):
            Q[(i, j), (i, j)] -= penalty
        for i1 in range(n_machines):
            for i2 in range(i1 + 1, n_machines):
                Q[(i1, j), (i2, j)] = 2 * penalty

    # Define the BinaryQuadraticModel
    bqm = dimod.BQM(Q, "BINARY")

    # Define the sampler
    sampler = neal.SimulatedAnnealingSampler()

    # Sample
    response = sampler.sample(bqm, num_reads=num_reads)

    # Get the sample with the smallest energy
    sample = response.first.sample

    # Convert the sample to a pandas DataFrame
    solution = pd.DataFrame(0, index=np.arange(n_steps), columns=np.arange(n_machines))
    for key, value in sample.items():
        if value == 1:
            solution.loc[key[1], key[0]] = 1

    return {"solution": solution, "sample": sample}


def machine_selection(machine_type, availability_zones, num_hours):

    solution_string = ""

    normal_graphs = []
    rolling_graphs = []

    forecasts = []
    expected_savings = []

    # for zone in availability_zones:
    #     get_spot_price_data(machine_type, zone)
    df = prepare_all_data(machine_type, last_samples=5000)

    for zone in availability_zones:
        forecast_result = forecast(machine_type, zone, num_hours, df)
        forecasts.append(forecast_result["results"])
        normal_graphs.append(forecast_result["normal_results"])
        rolling_graphs.append(forecast_result["rolling_results"])
        solution_string += (
            forecast_result["decision_comments"]
            + "\n"
            + f"Expected savings: {forecast_result['expected_savings']}"
            + "\n"
        )
        expected_savings.append(forecast_result["expected_savings"])

    df = pd.concat(forecasts, axis=1)

    final_result = machine_selection_algorithm(df)

    df.reset_index(inplace=True, drop=True)
    df.to_csv("forecast_results.csv", index=False)

    solution = final_result["solution"]

    solution.columns = availability_zones

    chosen_zones = solution.idxmax(axis=1)

    chosen_zone_result = "Chosen final machines for each time-step"

    for idx, zone in enumerate(chosen_zones):
        chosen_zone_result += f"\nTime Step {idx}: {zone}"

    solution_string += (
        "Final result from solver: "
        + "\n"
        + solution.to_string()
        + "\n"
        + chosen_zone_result
    )

    return (
        solution,
        solution_string,
        normal_graphs,
        rolling_graphs,
        expected_savings,
        df,
    )


llm = ChatGoogleGenerativeAI(
    model="gemini-pro",
    convert_system_message_to_human=True,
    safety_settings={
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
    },
)

aws_access_key_id = "your key"
aws_secret_access_key = "your key"

# Define dropdown options for machine types
machine_types = ["g4dn.xlarge", "g4dn.2xlarge", "g4dn.4xlarge"]

av_zones = ["us-east-1a", "us-east-1b", "us-east-1c", "us-east-1d"]


def check_machine_type_availability(machine_type, availability_zone):
    """
    Checks if a specific machine type is available in a given availability zone.

    Args:
        machine_type: The name of the machine type (e.g., m5.xlarge).
        availability_zone: The availability zone (e.g., us-east-1a).

    Returns:
        True if the machine type is available, False otherwise.
    """
    # Create an EC2 client
    ec2_client = boto3.client(
        "ec2",
        region_name=availability_zone[:-1],
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )

    # Use DescribeInstanceTypeOfferings to check availability
    try:
        response = ec2_client.describe_instance_type_offerings(
            LocationType="availability-zone",
            Filters=[
                {"Name": "location", "Values": [availability_zone]},
                {"Name": "instance-type", "Values": [machine_type]},
            ],
        )
    except NoCredentialsError as error:
        print("No credentials have been found.")
        print(f"Error checking availability: {error}")
        return False

    # Check if any offerings were found
    return len(response["InstanceTypeOfferings"]) > 0


def get_available_zones(machine_type):
    az = []
    for zone in av_zones:
        if check_machine_type_availability(machine_type, zone):
            az.append(zone)

    return az


STANDARD_SYSTEM_PROMPT = """
    You are a helpful and smart assistant named SpotGem whose primary job is to answer questions on technical decisions
    that were made during the selection of AWS EC2 spot machines. You have access to an Agent Scratchpad
    that has the information you need about how the decisions were made and the forecasted prices for the
    machines. If asked why a decision was made, you can reference the information available to you in the
    agent scratchpad. The obvious answers relate to how the prices for a certain availability zone were lower than
    the prices in other zones.
    Answer the questions asked by the user while referencing the information available to you. Do not
    create or make up any information that is not available to you. Always provide a helpful response and
    never say no to a question. You got this, you can do this!
"""

prompt = ChatPromptTemplate.from_messages(
    [
        ("human", STANDARD_SYSTEM_PROMPT),
        ("ai", "{agent_scratchpad}"),
        ("human", "{history}"),
        ("ai", "No Response"),
        ("human", "{message}"),
    ]
)

output_parser = StrOutputParser()

chain = (
    {
        "agent_scratchpad": lambda x: x["agent_scratchpad"],
        "history": lambda x: x["history"],
        "message": lambda x: x["message"],
    }
    | prompt
    | llm
    | output_parser
)


def invoke_tool(machine_type, num_hours):
    machine_av_zones = get_available_zones(machine_type)

    (
        result,
        result_string,
        normal_results,
        rolling_results,
        expected_savings,
        prices_df,
    ) = machine_selection(
        machine_type=machine_type,
        availability_zones=machine_av_zones,
        num_hours=num_hours,
    )

    return (
        result,
        result_string,
        normal_results,
        rolling_results,
        expected_savings,
        prices_df,
    )


def invoke_llm(message, chat_history, scratchpad):

    graph = check_for_graph_question(message)

    res = chain.invoke(
        {
            "message": message,
            "history": chat_history if len(chat_history) == 0 else chat_history[0],
            "agent_scratchpad": scratchpad,
        }
    )

    if graph is not None:
        res_list = [res, graph]
    else:
        res_list = [res]

    return res_list, chat_history


def process_history(history_obj):
    history = []

    if len(history_obj[0]) == 0:
        return history

    for idx, obj in enumerate(history_obj):
        if idx % 2 == 0:
            history.append(("human", obj))
        else:
            history.append(("ai", obj))

    return history


def format_json_table(df, price_vals):
    df_dict = df.T.to_dict()
    results = [vals for vals in df_dict.values()]
    results = solution_mapper(results, price_vals)
    return results


app = Flask(__name__)
CORS(app)


def _build_cors_preflight_response():
    response = make_response()
    response.headers.add("Access-Control-Allow-Origin", "*")
    response.headers.add("Access-Control-Allow-Headers", "*")
    response.headers.add("Access-Control-Allow-Methods", "*")
    return response


@app.route("/invoke_tool", methods=["POST", "OPTIONS"])
def invoke_tool_api():
    if request.method == "OPTIONS":
        return _build_cors_preflight_response()
    data = request.get_json()
    chosen_machine_type = data.get("chosenMachineType")
    num_hours = data.get("numHours")

    if not all([chosen_machine_type, num_hours]):
        return jsonify({"error": "Missing required parameters"}), 400

    (
        result,
        result_string,
        normal_results,
        rolling_results,
        expected_savings,
        prices_df,
    ) = invoke_tool(chosen_machine_type, num_hours)

    return jsonify(
        {
            # the dataframe, formatted as a dictionary, to be shown on the UI
            "solution": format_json_table(result, prices_df),
            # to be used as input to agent scratchpad in the chat
            "solutionString": result_string,
            "normal_results_b64": normal_results,
            "rolling_results_b64": rolling_results,
            "expected_savings": expected_savings,
        }
    )


@app.route("/invoke_llm", methods=["POST", "OPTIONS"])
def invoke_llm_api():
    if request.method == "OPTIONS":
        return _build_cors_preflight_response()
    data = request.get_json()
    message = data.get("message")
    history = process_history(data.get("history"))
    agent_scratchpad = data.get("agentScratchpad")

    # if not all([message, history, agent_scratchpad]):
    #     return jsonify({'error': 'Missing required parameters'}), 400

    # invokes gemini api with information
    output, chat_history = invoke_llm(message, history, agent_scratchpad)
    # at hand and returns the output and updated chat history
    return jsonify({"output": output, "chatHistory": chat_history})


if __name__ == "__main__":
    app.run(debug=True)
